<!doctype html>
<html>
<?php include'includes/head.php';?>
<body>
<?php include'includes/header.php';?>
    <div id="container">
	
<?php include 'includes/aside.php';?>