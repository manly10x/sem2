 <footer>
        &copy; AnAirlines All rights reserved. Developed by Zcoding coding group.
    </footer>