<header>
      
      <h1 class="logo">An Airlines</h1>
       <?php include 'includes/menu.php';?>
        <div class="clear"></div>
    </header>