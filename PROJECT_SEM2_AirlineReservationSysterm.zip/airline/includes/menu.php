       <nav>
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="flight.php">Flight</a></li>
                <li><a href="about.php">About us</a></li>
                <li><a href="contact.php">Contact us</a></li>
            </ul>
        </nav>