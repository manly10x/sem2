<?php
include 'core/init.php';
include 'includes/overall/header.php';?>
<h2>About us</h2>
	<p>
AnAirlines’s mission is to become India’s preferred low-cost airline,delivering the lowest air fares<br>
with the highest consumer value,to price sensitive consumers to fulfill everyone’s dream of flying!<br>
With India's economic and business growth,the percentage of traveling population is burgeoning.<br>
Indians are traveling for both business,pleasure and everyone needs to save both time and money.<br>
AnAirlines’s  vision is to address that and ensure that flying is for everyone.<br>
The power to fly for everyone with a dynamic fare structure. <br>
	</p>
	<h3>Careers</h3>
	<p>
	At AnAirlines, we believe that our people are our greatest asset. We are always on a lookout for highly<br>
	motivated individuals who can collaborate with like-minded people in an environment that embraces<br> 
	individuality and rewards your best work. A career opportunity at AnAirlines will entail you to unlimited <br>
	opportunities and a host of benefits. Come, be a part of AnAirlines.<br>
	</p>
	<div>
	<br>
	<br>
					<img src="about.jpg">
					</div>
<?php include 'includes/overall/footer.php';?>