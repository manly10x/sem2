
<?php
include 'core/init.php';
include 'includes/overall/header.php';?>
<?php include("slider.php");?>
 <style>
 img{
	 float:left;
 }
 </style>

<div id="indexpics">
<img src="eiffel.jpg">
<h3><b><a href="flight.php">&nbsp;Paris&nbsp; 10% off &nbsp; &nbsp; Book Now >></a></b></h3>
</div>
<div id="indexpics">
<img src="ny.jpg">

<h3><b><a href="flight.php">&nbsp;New york&nbsp; 15% off &nbsp; &nbsp; Book Now >></a></b></h3>
</div>
<div id="indexpics">
<img src="taj.jpg">
<h3><b><a href="flight.php">&nbsp;Agra&nbsp; 20% off &nbsp; &nbsp; Book Now >></a></b></h3>


</div>

<?php include 'includes/overall/footer.php';?>