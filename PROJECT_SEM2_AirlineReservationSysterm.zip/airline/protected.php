<?php
include 'core/init.php';
include 'includes/overall/header.php';?>
<h2>Sorry, you need to be logged in to do that</h2>
<p>Please register or login!</p>
<?php include 'includes/overall/footer.php';?>